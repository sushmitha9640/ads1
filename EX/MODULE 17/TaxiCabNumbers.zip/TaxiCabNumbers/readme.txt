Input format:
First line of the input contains two integers(N,M) seperated with space
Output format:
Print the Nth number that can be represented as sum of cubes of two different numbers M times

Sample input:
1 2

Sample output:
1729

Explanation:
1729 is the 1st number that can be represented as sum of cubes of two different numbers 2 times



Sample input:
3 3

Sample Output:
143604279

Explanation:
143604279 is the 3rd number that can be represented as sum of cubes of two different numbers 3 times